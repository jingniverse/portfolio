# Snowball Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/wvXbboe](https://codepen.io/jkantner/pen/wvXbboe).

Hm… a snowman in progress?